------------------------------------------------------------------                                                               
 
                             TCP Viewer

                            Version 2.83

------------------------------------------------------------------

------------------------------------------------------------------
CONTENTS
------------------------------------------------------------------
INTRODUCTION
DETAILS 
COMMAND-LINE PARAMETERS
REQUIREMENTS
DISTRIBUTING
CONTACT INFORMATION

------------------------------------------------------------------
INTRODUCTION
------------------------------------------------------------------
TCP Viewer captures and displays all data that is transferred between client
processes and a server process communicating through TCP/IP. The processes can
be running on the same machine or different machines located anywhere on a
network or the Internet. TCP Viewer can run on a machine different than the
machine(s) that the processes are running on. An example of a client and server
is a web browser and web server.

TCP Viewer can be used by a developer to debug protocol problems or by anyone
who is curious about what data is passed between processes.

------------------------------------------------------------------
DETAILS
------------------------------------------------------------------
TCP Viewer is a TCP tunnel. It is an intermediary program which acts as a
blind relay. It is protocol agnostic. TCP Viewer captures and displays the
data that it passes from clients to the intended server and vice-versa. 

For a client to connect to a server, it must know the name or IP address of
the machine that the server is running on, and which port number the server
has established. The name or IP address of a machine is like the zip code of a
mailing address. The port number is like the street address. You may be
unaware of port numbers because most protocols have a default port number that
is usually used. For example, HTTP's default port number is 80. Telnet's is
23.

To use TCP Viewer, TCP Viewer needs to be configured to communicate with the
intended server and the client needs to be reconfigured to communicate with
TCP Viewer. Another option is for the intended server to listen on a different
port number than originally configured, and for TCP Viewer to run on the same
machine as the intended server at the port number that the intended server was
listening on. In the latter, the client configuration does not change. This is
easier than it sounds and an example of the first will follow.

TCP Viewer works great with protocols, such as Telnet, that have a constant
connection. For HTTP, use HTTP Recorder.

The following is an example on how to use TCP Viewer with HTTP, without
considering whether a proxy is being used.

1. Provide TCP Viewer with the name or IP address of the machine that the
   intended server is running on (Remote Host), and the port number that the
   intended server has established (Remote Port). For example,
   Remote Host=www.yahoo.com, Remote Port=80.
2. Provide TCP Viewer with a arbitrary port number to establish (Local Port).
   If 0 is provided, TCP Viewer will ask the OS for an available port number
   and display it. For example, Local Port=9000.
3. Click TCP Viewer's Start button.
4. Configure a client to connect to TCP Viewer instead of the intended server.
   This involves providing a client with the name or IP address of the machine
   that TCP Viewer is running on, instead of the machine that the intended
   server is running on, and the port number that TCP Viewer has established,
   instead of the port number that the intended server has established. For
   example, http://127.0.0.1:9000. Substitute 127.0.0.1 with the IP address of
   the machine that TCP Viewer is running on. TCP Viewer shows this IP address
   on its status bar.

TCP Viewer displays its output in a scrollable text box. This data may
additionally be sent to a file as text or HTML. By default, only 32KB of data
is kept in the scrollable text box. Higher data limits may be selected,
including unlimited. It handles more than one connection.

Based upon the first transferred message, TCP Viewer will determine if the
protocol is text based. If so, TCP Viewer will test each following message for
text. If a message contains only text, TCP Viewer will display it as such.
Else, TCP Viewer will show the message in hexadecimal and ASCII. If the
protocol is HTTP, the HTTP headers will be displayed as text.

------------------------------------------------------------------
COMMAND-LINE PARAMETERS
------------------------------------------------------------------
No command-line parameters need to be provided to TCP Viewer. If provided, it
must conform to the following Usage statement:

Usage: TCPVIEWR <remote host> <remote port> <local port> [-file <log file>]
  [-size 32KB|128KB|512KB|2MB|Unlimited] [-detail Low|Medium|High] [-auto]

 -auto causes TCP Viewer to 'Start' automatically. And, it will not prompt for
confirmation, when closing, if the local port is still opened.

For example, 'TCPVIEWR www.yahoo.com 80 9000 -file YAHOO.TXT -auto'.

------------------------------------------------------------------
REQUIREMENTS
------------------------------------------------------------------
* Windows 98/ME/NT4/2000/XP/2003
* 2MB RAM 
* 1MB hard disk space 

------------------------------------------------------------------
DISTRIBUTING
------------------------------------------------------------------
You may make as many copies of the software as you wish; give exact copies of
it to anyone; and distribute the software in its unmodified form via
electronic means. There is no charge for any of the above.

------------------------------------------------------------------
CONTACT INFORMATION
------------------------------------------------------------------
Name
David Westbrook

Electronic Mail Address
david@westbrooksoftware.com

Phone
(904)996-8302

World Wide Web
http://www.westbrooksoftware.com

Address
11129 Harbour North Lane
Jacksonville, FL 32225


